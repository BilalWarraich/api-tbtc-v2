'use strict';

var build = require('litecore-build');

build('explorers');

